import HomeBanner from "@/components/home/HomeBanner";
import React from "react";

const index = () => {
  return (
    <>
      <HomeBanner />
    </>
  );
};

export default index;
